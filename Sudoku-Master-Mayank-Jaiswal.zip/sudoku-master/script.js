const boardElement = document.getElementById("board");
const difficultySelect = document.getElementById("difficulty");
const messageElement = document.getElementById("message");
const timerElement = document.getElementById("timer");
const mistakesElement = document.getElementById("mistakes");
const hintsElement = document.getElementById("hints");

let solution = [];
let puzzle = [];
let startingPuzzle = [];
let selectedCell = null;
let mistakes = 0;
let hints = 0;
let seconds = 0;
let timerInterval = null;
let gameFinished = false;

function copyGrid(grid) {
  return grid.map(row => [...row]);
}

function shuffle(items) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function isSafe(grid, row, col, number) {
  for (let i = 0; i < 9; i++) {
    if (grid[row][i] === number || grid[i][col] === number) return false;
  }
  const startRow = Math.floor(row / 3) * 3;
  const startCol = Math.floor(col / 3) * 3;
  for (let r = startRow; r < startRow + 3; r++) {
    for (let c = startCol; c < startCol + 3; c++) {
      if (grid[r][c] === number) return false;
    }
  }
  return true;
}

function fillGrid(grid) {
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      if (grid[row][col] === 0) {
        for (const number of shuffle([1,2,3,4,5,6,7,8,9])) {
          if (isSafe(grid, row, col, number)) {
            grid[row][col] = number;
            if (fillGrid(grid)) return true;
            grid[row][col] = 0;
          }
        }
        return false;
      }
    }
  }
  return true;
}

function createPuzzle() {
  const solved = Array.from({ length: 9 }, () => Array(9).fill(0));
  fillGrid(solved);
  const puzzleGrid = copyGrid(solved);
  const blanks = { easy: 34, medium: 44, hard: 52 }[difficultySelect.value];

  let removed = 0;
  while (removed < blanks) {
    const row = Math.floor(Math.random() * 9);
    const col = Math.floor(Math.random() * 9);
    if (puzzleGrid[row][col] !== 0) {
      puzzleGrid[row][col] = 0;
      removed++;
    }
  }
  return { solved, puzzleGrid };
}

function startTimer() {
  clearInterval(timerInterval);
  seconds = 0;
  updateTimer();
  timerInterval = setInterval(() => {
    if (!gameFinished) {
      seconds++;
      updateTimer();
    }
  }, 1000);
}

function updateTimer() {
  const minutes = String(Math.floor(seconds / 60)).padStart(2, "0");
  const remainingSeconds = String(seconds % 60).padStart(2, "0");
  timerElement.textContent = `${minutes}:${remainingSeconds}`;
}

function showMessage(text, type = "") {
  messageElement.textContent = text;
  messageElement.className = `message ${type}`;
}

function renderBoard() {
  boardElement.innerHTML = "";
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      const button = document.createElement("button");
      const value = puzzle[row][col];
      button.className = "cell";
      button.type = "button";
      button.setAttribute("role", "gridcell");
      button.setAttribute("aria-label", `Row ${row + 1}, column ${col + 1}${value ? `, ${value}` : ", empty"}`);
      button.dataset.row = row;
      button.dataset.col = col;
      button.textContent = value || "";
      if (startingPuzzle[row][col] !== 0) button.classList.add("fixed");
      if (selectedCell && selectedCell.row === row && selectedCell.col === col) button.classList.add("selected");
      if (selectedCell && (selectedCell.row === row || selectedCell.col === col ||
          (Math.floor(selectedCell.row / 3) === Math.floor(row / 3) &&
           Math.floor(selectedCell.col / 3) === Math.floor(col / 3)))) {
        button.classList.add("related");
      }
      if (selectedCell && value && value === puzzle[selectedCell.row][selectedCell.col]) {
        button.classList.add("same-number");
      }
      if (value && startingPuzzle[row][col] === 0 && value !== solution[row][col]) {
        button.classList.add("error");
      }
      button.addEventListener("click", () => {
        selectedCell = { row, col };
        renderBoard();
      });
      boardElement.appendChild(button);
    }
  }
}

function updateStats() {
  mistakesElement.textContent = mistakes;
  hintsElement.textContent = hints;
}

function newGame() {
  const game = createPuzzle();
  solution = game.solved;
  puzzle = copyGrid(game.puzzleGrid);
  startingPuzzle = copyGrid(game.puzzleGrid);
  selectedCell = null;
  mistakes = 0;
  hints = 0;
  gameFinished = false;
  updateStats();
  renderBoard();
  startTimer();
  showMessage("New puzzle ready. Good luck!");
}

function enterNumber(number) {
  if (!selectedCell || gameFinished) {
    showMessage("Please select an empty cell first.", "error-text");
    return;
  }
  const { row, col } = selectedCell;
  if (startingPuzzle[row][col] !== 0) {
    showMessage("That number is part of the original puzzle.");
    return;
  }
  puzzle[row][col] = number;
  if (number !== 0 && number !== solution[row][col]) {
    mistakes++;
    showMessage("That number does not fit. Try another one.", "error-text");
  } else {
    showMessage(number === 0 ? "Cell cleared." : "Good choice!");
  }
  updateStats();
  renderBoard();
  if (isPuzzleComplete()) finishGame();
}

function isPuzzleComplete() {
  return puzzle.every((row, r) => row.every((value, c) => value === solution[r][c]));
}

function finishGame() {
  gameFinished = true;
  clearInterval(timerInterval);
  showMessage(`Puzzle completed in ${timerElement.textContent}. Well done!`, "success");
}

document.getElementById("number-pad").addEventListener("click", event => {
  const button = event.target.closest("button[data-number]");
  if (button) enterNumber(Number(button.dataset.number));
});

document.addEventListener("keydown", event => {
  if (!selectedCell) return;
  if (/^[1-9]$/.test(event.key)) enterNumber(Number(event.key));
  if (event.key === "Backspace" || event.key === "Delete" || event.key === "0") enterNumber(0);
  const { row, col } = selectedCell;
  let next = null;
  if (event.key === "ArrowUp" && row > 0) next = { row: row - 1, col };
  if (event.key === "ArrowDown" && row < 8) next = { row: row + 1, col };
  if (event.key === "ArrowLeft" && col > 0) next = { row, col: col - 1 };
  if (event.key === "ArrowRight" && col < 8) next = { row, col: col + 1 };
  if (next) {
    selectedCell = next;
    renderBoard();
  }
});

document.getElementById("new-game").addEventListener("click", newGame);
document.getElementById("reset").addEventListener("click", () => {
  puzzle = copyGrid(startingPuzzle);
  mistakes = 0;
  hints = 0;
  gameFinished = false;
  updateStats();
  renderBoard();
  startTimer();
  showMessage("Board reset. Try again!");
});

document.getElementById("hint").addEventListener("click", () => {
  if (gameFinished) return;
  const emptyCells = [];
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      if (puzzle[row][col] === 0) emptyCells.push({ row, col });
    }
  }
  if (!emptyCells.length) {
    showMessage("There are no empty cells left.");
    return;
  }
  const cell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  puzzle[cell.row][cell.col] = solution[cell.row][cell.col];
  selectedCell = cell;
  hints++;
  updateStats();
  renderBoard();
  showMessage("One correct number has been filled in.");
  if (isPuzzleComplete()) finishGame();
});

document.getElementById("check").addEventListener("click", () => {
  let wrong = 0;
  let empty = 0;
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      if (puzzle[row][col] === 0) empty++;
      else if (puzzle[row][col] !== solution[row][col]) wrong++;
    }
  }
  renderBoard();
  if (wrong) showMessage(`${wrong} incorrect number(s) found. Red cells need attention.`, "error-text");
  else if (empty) showMessage(`All filled numbers are correct. ${empty} cell(s) remaining.`, "success");
  else finishGame();
});

difficultySelect.addEventListener("change", newGame);
newGame();
