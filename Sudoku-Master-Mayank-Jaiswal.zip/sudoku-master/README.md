# Sudoku Master

A browser-based Sudoku game made with plain HTML, CSS and JavaScript.

## Features
- Randomly generated 9 x 9 Sudoku boards
- Easy, Medium and Hard difficulty levels
- Select a cell and enter numbers using the number pad or keyboard
- Hint, Check Answers, Reset and New Game controls
- Timer, mistake counter and hint counter
- Responsive layout for laptop and mobile screens

## Run the project
1. Download or clone this repository.
2. Open the `sudoku-master` folder.
3. Double-click `index.html` to open it in a browser.

No installation or server is required.

## Files
- `index.html` – page structure
- `style.css` – layout and visual styling
- `script.js` – Sudoku generation and game logic

## GitHub upload
Create a new repository on GitHub, then upload these three files and this README. Keep all files in the same folder.

## Note
This is a learning project. The puzzle generator creates a completed valid Sudoku grid and removes cells to make a playable puzzle. The difficulty setting controls how many cells are removed.


## Troubleshooting
- Keep `index.html`, `style.css`, and `script.js` together in the same folder.
- Open `index.html` in an up-to-date browser such as Chrome or Edge.
- If an older copy is open, refresh the page after extracting the updated ZIP.

## Credits
Made by Mayank Jaiswal.
